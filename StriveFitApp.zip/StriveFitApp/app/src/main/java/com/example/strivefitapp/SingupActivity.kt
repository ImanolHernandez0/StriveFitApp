package com.example.strivefitapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class SingupActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_singup)

        val btnVolver = findViewById<Button>(R.id.btnVolver2)
        val btnRegistrar = findViewById<Button>(R.id.btnRegistrar)

        btnVolver.setOnClickListener {
            finish()
        }

        btnRegistrar.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

    }
}